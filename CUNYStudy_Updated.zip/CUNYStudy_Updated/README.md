# CUNYStudy Django Version

This version replaces browser `localStorage` with Django models and adds signup/login/logout.

## Run locally

```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
python manage.py migrate
python manage.py seed_groups
python manage.py runserver
```

Open http://127.0.0.1:8000

## Supabase setup

1. Create a Supabase project.
2. Go to Project Settings > Database.
3. Copy the **Session Pooler** connection string.
4. Paste it into `.env` as `DATABASE_URL=...`.
5. Run:

```bash
python manage.py migrate
python manage.py seed_groups
```

## Features added

- Django authentication: signup, login, logout
- Study groups stored in database
- Browse/search/filter groups
- Create groups only while logged in
- Join groups only while logged in
- Prevents duplicate joins
- Group creator is automatically a member
