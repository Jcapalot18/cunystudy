from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.db.models import Q, Count
from django.shortcuts import get_object_or_404, redirect, render
from .forms import SignUpForm, StudyGroupForm
from .models import Membership, StudyGroup

SUBJECTS = ['Computer Science','Mathematics','Biology','Chemistry','Psychology','English','History','Philosophy','Business']
CAMPUSES = ['College of Staten Island','Baruch College','Brooklyn College','City College','Hunter College','Queens College']
TYPES = ['In-Person','Online','Hybrid']
DAYS = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday']

def filtered_groups(request):
    groups = StudyGroup.objects.annotate(member_count=Count('memberships'))
    q = request.GET.get('q', '').strip()
    subject = request.GET.get('subject', 'all')
    campus = request.GET.get('campus', 'all')
    meeting_type = request.GET.get('type', 'all')
    day = request.GET.get('day', 'all')
    if q:
        groups = groups.filter(Q(course__icontains=q) | Q(course_name__icontains=q) | Q(professor__icontains=q) | Q(description__icontains=q) | Q(subject__icontains=q))
    if subject != 'all': groups = groups.filter(subject=subject)
    if campus != 'all': groups = groups.filter(campus=campus)
    if meeting_type != 'all': groups = groups.filter(meeting_type=meeting_type)
    if day != 'all': groups = groups.filter(day=day)
    return groups, {'q': q, 'subject': subject, 'campus': campus, 'type': meeting_type, 'day': day}

def home(request):
    groups = StudyGroup.objects.all()
    return render(request, 'groups/index.html', {
        'featured_groups': groups[:6],
        'group_count': groups.count(),
        'student_count': Membership.objects.count(),
        'course_count': groups.values('course').distinct().count(),
    })

def browse(request):
    groups = StudyGroup.objects.all()

    filters = {
        "q": request.GET.get("q", ""),
        "subject": request.GET.get("subject", "all"),
        "campus": request.GET.get("campus", "all"),
        "type": request.GET.get("type", "all"),
        "day": request.GET.get("day", "all"),
    }

    if filters["q"]:
        groups = groups.filter(
            course__icontains=filters["q"]
        ) | groups.filter(
            course_name__icontains=filters["q"]
        ) | groups.filter(
            professor__icontains=filters["q"]
        ) | groups.filter(
            subject__icontains=filters["q"]
        )

    if filters["subject"] != "all":
        groups = groups.filter(subject=filters["subject"])

    if filters["campus"] != "all":
        groups = groups.filter(campus=filters["campus"])

    if filters["type"] != "all":
        groups = groups.filter(meeting_type=filters["type"])

    if filters["day"] != "all":
        groups = groups.filter(day=filters["day"])

    return render(request, "groups/browse.html", {
        "groups": groups,
        "filters": filters,
        "subjects": SUBJECTS,
        "campuses": CAMPUSES,
        "types": TYPES,
        "days": DAYS,
    })

def group_detail(request, pk):
    group = get_object_or_404(StudyGroup, pk=pk)
    joined = request.user.is_authenticated and Membership.objects.filter(user=request.user, group=group).exists()
    progress = min(int((group.current_members / group.max_members) * 100), 100) if group.max_members else 0
    return render(request, 'groups/group.html', {'group': group, 'joined': joined, 'progress': progress})

@login_required
def create_group(request):
    if request.method == 'POST':
        form = StudyGroupForm(request.POST)
        if form.is_valid():
            group = form.save(commit=False)
            group.creator = request.user
            if not group.contact:
                group.contact = request.user.email
            group.save()
            Membership.objects.get_or_create(user=request.user, group=group)
            messages.success(request, 'Your study group was created.')
            return redirect('group_detail', pk=group.pk)
    else:
        form = StudyGroupForm(initial={'campus': 'College of Staten Island', 'contact': request.user.email})
    return render(request, 'groups/create.html', {'form': form})

@login_required
def join_group(request, pk):
    group = get_object_or_404(StudyGroup, pk=pk)
    if Membership.objects.filter(user=request.user, group=group).exists():
        messages.info(request, 'You already joined this group.')
    elif group.current_members >= group.max_members:
        messages.error(request, 'This group is already full.')
    else:
        Membership.objects.create(user=request.user, group=group)
        messages.success(request, f'You joined {group.course}. Contact: {group.contact}')
    return redirect('group_detail', pk=group.pk)

def about(request):
    return render(request, 'groups/about.html')

def signup(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.email = form.cleaned_data['email']
            user.save()
            login(request, user)
            messages.success(request, 'Account created. You are now logged in.')
            return redirect('home')
    else:
        form = SignUpForm()
    return render(request, 'registration/signup.html', {'form': form})
