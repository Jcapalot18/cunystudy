from django.core.management.base import BaseCommand
from groups.models import StudyGroup

SEED = [
  dict(course='CSC 226', course_name='Web Database Applications', professor='Prof. Tooker', campus='College of Staten Island', location='Library Building 1L-116', meeting_type='In-Person', day='Monday', time='2:00 PM', max_members=5, description='Working on the final project together. We cover SQL joins, Django, and building our website. Bring your laptop and any questions from lecture.', contact='csc226group@login.cuny.edu', subject='Computer Science'),
  dict(course='MTH 230', course_name='Discrete Mathematics', professor='Prof. Martinez', campus='College of Staten Island', location='Building 1N Room 215', meeting_type='In-Person', day='Wednesday', time='4:00 PM', max_members=4, description='Studying proofs, logic, and graph theory before the midterm.', contact='mth230study@login.cuny.edu', subject='Mathematics'),
  dict(course='PSY 100', course_name='Introduction to Psychology', professor='Prof. Chen', campus='College of Staten Island', location='Zoom', meeting_type='Online', day='Thursday', time='6:00 PM', max_members=6, description='Final exam review group. We share notes and quiz each other on chapters 1-10.', contact='psy100review@login.cuny.edu', subject='Psychology'),
  dict(course='ENG 151', course_name='English Composition', professor='Prof. Williams', campus='College of Staten Island', location='Coffee House Student Center', meeting_type='In-Person', day='Friday', time='11:00 AM', max_members=4, description='Peer review group for essay drafts.', contact='eng151write@login.cuny.edu', subject='English'),
  dict(course='CSC 215', course_name='Computer Organization', professor='Prof. Khazan', campus='College of Staten Island', location='Zoom', meeting_type='Online', day='Tuesday', time='7:00 PM', max_members=5, description='Going over assembly language and binary arithmetic.', contact='csc215group@login.cuny.edu', subject='Computer Science'),
  dict(course='BIO 150', course_name='General Biology', professor='Prof. Rivera', campus='College of Staten Island', location='Science Building 2S-118', meeting_type='In-Person', day='Saturday', time='10:00 AM', max_members=6, description='Cell biology and genetics review.', contact='bio150lab@login.cuny.edu', subject='Biology'),
]

class Command(BaseCommand):
    help = 'Seed starter study groups'
    def handle(self, *args, **kwargs):
        created = 0
        for data in SEED:
            _, was_created = StudyGroup.objects.get_or_create(course=data['course'], course_name=data['course_name'], defaults=data)
            created += int(was_created)
        self.stdout.write(self.style.SUCCESS(f'Seed complete. Created {created} groups.'))
