from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import StudyGroup

class SignUpForm(UserCreationForm):
    email = forms.EmailField(required=True, help_text='Use your school email.')

    class Meta:
        model = User
        fields = ('username', 'email', 'password1', 'password2')

    def clean_email(self):
        email = self.cleaned_data['email'].lower()
        if User.objects.filter(email=email).exists():
            raise forms.ValidationError('An account with this email already exists.')
        # Uncomment to enforce CUNY-only accounts:
        # if not email.endswith('.cuny.edu') and not email.endswith('@login.cuny.edu'):
        #     raise forms.ValidationError('Please use your CUNY email.')
        return email

class StudyGroupForm(forms.ModelForm):
    class Meta:
        model = StudyGroup
        fields = ['course','course_name','professor','subject','campus','meeting_type','location','day','time','max_members','contact','description']
        widgets = {
            'description': forms.Textarea(attrs={'rows': 5}),
        }
