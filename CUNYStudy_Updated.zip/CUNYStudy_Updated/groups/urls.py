from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('browse/', views.browse, name='browse'),
    path('groups/<int:pk>/', views.group_detail, name='group_detail'),
    path('groups/<int:pk>/join/', views.join_group, name='join_group'),
    path('create/', views.create_group, name='create_group'),
    path('about/', views.about, name='about'),
    path('signup/', views.signup, name='signup'),
]
