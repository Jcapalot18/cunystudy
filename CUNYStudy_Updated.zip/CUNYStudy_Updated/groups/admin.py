from django.contrib import admin
from .models import StudyGroup, Membership

@admin.register(StudyGroup)
class StudyGroupAdmin(admin.ModelAdmin):
    list_display = ('course', 'course_name', 'subject', 'campus', 'meeting_type', 'day', 'time', 'max_members', 'created_at')
    search_fields = ('course', 'course_name', 'professor', 'subject', 'campus')
    list_filter = ('subject', 'campus', 'meeting_type', 'day')

@admin.register(Membership)
class MembershipAdmin(admin.ModelAdmin):
    list_display = ('user', 'group', 'joined_at')
