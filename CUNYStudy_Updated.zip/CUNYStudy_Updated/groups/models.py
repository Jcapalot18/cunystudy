from django.conf import settings
from django.db import models

class StudyGroup(models.Model):
    MEETING_TYPES = [('In-Person','In-Person'), ('Online','Online'), ('Hybrid','Hybrid')]
    DAYS = [(d,d) for d in ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday']]

    course = models.CharField(max_length=20)
    course_name = models.CharField(max_length=120)
    professor = models.CharField(max_length=120, blank=True)
    subject = models.CharField(max_length=80)
    campus = models.CharField(max_length=120, default='College of Staten Island')
    location = models.CharField(max_length=160)
    meeting_type = models.CharField(max_length=20, choices=MEETING_TYPES)
    day = models.CharField(max_length=20, choices=DAYS)
    time = models.CharField(max_length=30)
    max_members = models.PositiveIntegerField(default=5)
    description = models.TextField()
    contact = models.EmailField()
    creator = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='created_groups', null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f'{self.course} - {self.course_name}'

    @property
    def current_members(self):
        return self.memberships.count()

    @property
    def spots_left(self):
        return max(self.max_members - self.current_members, 0)

    @property
    def status(self):
        if self.current_members >= self.max_members:
            return 'Full'
        if self.current_members >= round(self.max_members * 0.7):
            return 'Almost Full'
        return 'Open'

    @property
    def status_class(self):
        return {'Full': 'badge-full', 'Almost Full': 'badge-almost'}.get(self.status, 'badge-open')

class Membership(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='study_memberships')
    group = models.ForeignKey(StudyGroup, on_delete=models.CASCADE, related_name='memberships')
    joined_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('user', 'group')
